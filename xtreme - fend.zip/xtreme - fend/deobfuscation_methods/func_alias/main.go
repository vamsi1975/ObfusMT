package main

import (
	"encoding/json"
	"net/http"
	"regexp"
)

var reverseMap map[string]string // alias → original

func dealiasFunctions(code string) string {
	for alias, original := range reverseMap {
		// Replace function declarations
		declRe := regexp.MustCompile(`\bfunction\s+` + regexp.QuoteMeta(alias) + `\b`)
		code = declRe.ReplaceAllString(code, "function "+original)

		// Replace calls
		callRe := regexp.MustCompile(`\b` + regexp.QuoteMeta(alias) + `\s*\(`)
		code = callRe.ReplaceAllString(code, original+"(")
	}
	return code
}

func handler(w http.ResponseWriter, r *http.Request) {
	var data struct {
		Code    string            `json:"code"`
		Mapping map[string]string `json:"mapping"` // original → alias
	}
	err := json.NewDecoder(r.Body).Decode(&data)
	if err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}

	reverseMap = make(map[string]string)
	for orig, alias := range data.Mapping {
		reverseMap[alias] = orig
	}

	unaliased := dealiasFunctions(data.Code)

	json.NewEncoder(w).Encode(map[string]string{"code": unaliased})
}

func main() {
	http.HandleFunc("/obfuscate", handler)
	println("function_dealiaser running on :6004")
	http.ListenAndServe(":6004", nil)
}
