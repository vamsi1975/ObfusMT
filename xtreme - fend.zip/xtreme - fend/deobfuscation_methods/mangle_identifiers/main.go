package main

import (
	"encoding/json"
	"net/http"
	"regexp"
)

var reverseMap map[string]string // mangled → original

func unmangleIdentifiers(js string) string {
	for mangled, original := range reverseMap {
		re := regexp.MustCompile(`\b` + regexp.QuoteMeta(mangled) + `\b`)
		js = re.ReplaceAllString(js, original)
	}
	return js
}

func handler(w http.ResponseWriter, r *http.Request) {
	var data struct {
		Code    string            `json:"code"`
		Mapping map[string]string `json:"mapping"` // original -> mangled
	}
	err := json.NewDecoder(r.Body).Decode(&data)
	if err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}

	// Build reverse mapping
	reverseMap = make(map[string]string)
	for orig, mangled := range data.Mapping {
		reverseMap[mangled] = orig
	}

	unmangled := unmangleIdentifiers(data.Code)

	json.NewEncoder(w).Encode(map[string]string{"code": unmangled})
}

func main() {
	http.HandleFunc("/obfuscate", handler)
	println("identifier_unmangler running on :6002")
	http.ListenAndServe(":6002", nil)
}
