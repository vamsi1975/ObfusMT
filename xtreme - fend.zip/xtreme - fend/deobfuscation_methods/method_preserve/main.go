package main

import (
	"encoding/json"
	"net/http"
	"regexp"
)

func restoreMethods(code string) string {
	return regexp.MustCompile(`_METHODPLACEHOLDER`).ReplaceAllString(code, "")
}

func handler(w http.ResponseWriter, r *http.Request) {
	var data map[string]string
	json.NewDecoder(r.Body).Decode(&data)
	code := data["code"]
	restored := restoreMethods(code)
	json.NewEncoder(w).Encode(map[string]string{"code": restored})
}

func main() {
	http.HandleFunc("/obfuscate", handler)
	println("method_restorer running on :6005")
	http.ListenAndServe(":6005", nil)
}
