package main

import (
	"encoding/json"
	"net/http"
	"regexp"
	"strconv"
	"strings"
)

func decodeStringLiterals(code string) string {
	re := regexp.MustCompile(`"((?:\\x[0-9a-fA-F]{2})*)"`)
	return re.ReplaceAllStringFunc(code, func(s string) string {
		// remove quotes
		hexStr := s[1 : len(s)-1]

		var sb strings.Builder
		for i := 0; i < len(hexStr); i += 4 { // \xHH length 4
			hexByte := hexStr[i+2 : i+4]
			b, err := strconv.ParseUint(hexByte, 16, 8)
			if err != nil {
				return s // fallback: return original
			}
			sb.WriteByte(byte(b))
		}

		return `"` + sb.String() + `"`
	})
}

func handler(w http.ResponseWriter, r *http.Request) {
	var data map[string]string
	json.NewDecoder(r.Body).Decode(&data)
	decoded := decodeStringLiterals(data["code"])
	json.NewEncoder(w).Encode(map[string]string{"code": decoded})
}

func main() {
	http.HandleFunc("/obfuscate", handler)
	println("string_decoder running on :6003")
	http.ListenAndServe(":6003", nil)
}
