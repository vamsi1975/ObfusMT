// string_encoder.go
package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"regexp"
)

func encodeStringLiterals(code string) string {
	re := regexp.MustCompile(`"((?:\\"|[^"])*)"`)
	return re.ReplaceAllStringFunc(code, func(s string) string {
		// Remove surrounding quotes
		raw := s[1 : len(s)-1]
		encoded := ""
		// Handle each character
		for _, c := range raw {
			encoded += fmt.Sprintf("\\x%02x", c)
		}
		return `"` + encoded + `"`
	})
}

func handler(w http.ResponseWriter, r *http.Request) {
	var data map[string]string
	json.NewDecoder(r.Body).Decode(&data)
	encoded := encodeStringLiterals(data["code"])
	json.NewEncoder(w).Encode(map[string]string{"code": encoded})
}

func main() {
	http.HandleFunc("/obfuscate", handler)
	println("string_encoder running on :5003")
	http.ListenAndServe(":5003", nil)
}
