package main

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"net/http"
	"regexp"
	"sort"
	"strings"
)

// -------------- Deobfuscation Logic -----------------

func deobfuscateJS(code string) string {
	// Step 1: Decode hex literals
	code = decodeHexLiterals(code)

	// Step 2: Decode base64 eval(atob("..."))
	code = decodeBase64Wrapped(code)

	// Step 3: Demangle identifiers
	code = deobfuscateIdentifiers(code)

	// Step 4: Format JS
	code = formatJS(code)
	return code
}

func decodeHexLiterals(code string) string {
	decodePattern := regexp.MustCompile(`"((?:\\x[0-9a-fA-F]{2})+)"`)
	return decodePattern.ReplaceAllStringFunc(code, func(match string) string {
		encoded := match[1 : len(match)-1] // remove quotes
		decoded, err := decodeHexString(encoded)
		if err != nil {
			return match
		}
		return fmt.Sprintf(`"%s"`, decoded)
	})
}

func decodeBase64Wrapped(code string) string {
	base64Pattern := regexp.MustCompile(`eval\s*\(\s*atob\s*\(\s*"(.*?)"\s*\)\s*\)`)
	return base64Pattern.ReplaceAllStringFunc(code, func(match string) string {
		submatches := base64Pattern.FindStringSubmatch(match)
		if len(submatches) < 2 {
			return match
		}
		decodedBytes, err := base64.StdEncoding.DecodeString(submatches[1])
		if err != nil {
			return match
		}
		return string(decodedBytes)
	})
}

func decodeHexString(encoded string) (string, error) {
	unescaped := strings.ReplaceAll(encoded, `\x`, "")
	bytes := make([]byte, len(unescaped)/2)
	for i := 0; i < len(bytes); i++ {
		fmt.Sscanf(unescaped[2*i:2*i+2], "%02x", &bytes[i])
	}
	return string(bytes), nil
}

func deobfuscateIdentifiers(code string) string {
	reserved := map[string]bool{
		"let": true, "var": true, "const": true, "function": true, "return": true,
		"if": true, "else": true, "true": true, "false": true, "console": true, "log": true,
	}

	identifierPattern := regexp.MustCompile(`\b_?[a-zA-Z]{1,2}[0-9a-fA-F]{4,}\b`)
	matches := identifierPattern.FindAllString(code, -1)

	identifierSet := make(map[string]bool)
	for _, ident := range matches {
		if !reserved[ident] {
			identifierSet[ident] = true
		}
	}

	uniqueIdentifiers := make([]string, 0, len(identifierSet))
	for k := range identifierSet {
		uniqueIdentifiers = append(uniqueIdentifiers, k)
	}
	sort.Strings(uniqueIdentifiers)

	idMap := make(map[string]string)
	varCount := 1
	funcCount := 1

	for _, ident := range uniqueIdentifiers {
		funcPattern := regexp.MustCompile(fmt.Sprintf(`(?s)function\s+%s\s*\(`, ident))
		if funcPattern.MatchString(code) {
			idMap[ident] = fmt.Sprintf("func%d", funcCount)
			funcCount++
		} else {
			idMap[ident] = fmt.Sprintf("var%d", varCount)
			varCount++
		}
	}

	for obf, deobf := range idMap {
		pattern := regexp.MustCompile(`\b` + regexp.QuoteMeta(obf) + `\b`)
		code = pattern.ReplaceAllString(code, deobf)
	}

	return code
}

func formatJS(code string) string {
	code = regexp.MustCompile(`\s*([{};(),=+\-*/<>])\s*`).ReplaceAllString(code, " $1 ")
	code = regexp.MustCompile(`\s{2,}`).ReplaceAllString(code, " ")
	code = regexp.MustCompile(`;\s*`).ReplaceAllString(code, ";\n")
	code = regexp.MustCompile(`{\s*`).ReplaceAllString(code, "{\n")
	code = regexp.MustCompile(`}\s*`).ReplaceAllString(code, "}\n")

	lines := strings.Split(code, "\n")
	indentLevel := 0
	for i, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" {
			lines[i] = ""
			continue
		}
		if strings.HasPrefix(line, "}") {
			indentLevel--
		}
		if indentLevel < 0 {
			indentLevel = 0
		}
		lines[i] = strings.Repeat("\t", indentLevel) + line
		if strings.HasSuffix(line, "{") {
			indentLevel++
		}
	}
	return strings.Join(lines, "\n")
}

// -------------- HTTP Server Logic -----------------

func deobfuscationHandler(w http.ResponseWriter, r *http.Request) {
	var data map[string]string
	err := json.NewDecoder(r.Body).Decode(&data)
	if err != nil || data["code"] == "" {
		http.Error(w, "Invalid input", http.StatusBadRequest)
		return
	}
	result := deobfuscateJS(data["code"])
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"code": result})
}

func main() {
	http.HandleFunc("/obfuscate", deobfuscationHandler)
	fmt.Println("Deobfuscator running on :6001")
	http.ListenAndServe(":6001", nil)
}
