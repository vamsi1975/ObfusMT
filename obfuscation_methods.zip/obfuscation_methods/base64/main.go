package main

import (
	"encoding/base64"
	"encoding/json"
	"net/http"
	"strings"
	"unicode"
)

func sanitizeJS(js string) string {
	return strings.Map(func(r rune) rune {
		if unicode.IsSpace(r) || r == '\u00A0' || r == '\u200B' {
			return ' '
		}
		return r
	}, js)
}

func encodeStrings(js string) string {
	js = sanitizeJS(js)
	encoded := base64.StdEncoding.EncodeToString([]byte(js))
	return `eval(atob("` + encoded + `"));` // ✅ CORRECT: No extra quote or parenthesis
}

func handler(w http.ResponseWriter, r *http.Request) {
	var data map[string]string
	json.NewDecoder(r.Body).Decode(&data)
	encoded := encodeStrings(data["code"])
	json.NewEncoder(w).Encode(map[string]string{"code": encoded})
}

func main() {
	http.HandleFunc("/obfuscate", handler)
	println("string_encoder running on :5006")
	http.ListenAndServe(":5006", nil)
}
